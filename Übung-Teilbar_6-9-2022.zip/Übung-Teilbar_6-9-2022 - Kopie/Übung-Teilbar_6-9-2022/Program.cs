﻿using System;

namespace Übung_Teilbar_6_9_2022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int Anzahl, Summe;
            MTeilbar(1, 20, 2, out Anzahl, out Summe);

            Console.WriteLine($"Anzahl der Teilbaren Zahlen: {Anzahl}");
            Console.WriteLine($"Summe der Teilbaren Zahlen: {Summe}");
        }
        public static void MTeilbar(int mStart, int mEnde, int mTeiler,
            out int mAnzahl, out int mSumme)
        {
            mAnzahl = 0;
            mSumme = 0;

            if (mEnde < mStart)
            {
                Console.WriteLine("Error!");
                return;
            }
            if (mTeiler == 0)
            {
                Console.WriteLine("Error!");
                return;
            }

            for (int i = mStart; i <= mEnde; i++)
            {
                if (i % mTeiler == 0)
                {
                    mAnzahl++;
                    mSumme += i;
                }
            }
        }
    }
}
